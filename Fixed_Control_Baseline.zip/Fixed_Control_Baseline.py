import traci

traci.start(["sumo-gui", "-c", "simulation.sumocfg"])
step = 0
total_waiting_time_fixed = 0

while step < 1000:
    traci.simulationStep()
    # ACCURATE MEASUREMENT: Sum of waiting time for ALL cars at every step
    total_waiting_time_fixed += sum([traci.vehicle.getWaitingTime(v) for v in traci.vehicle.getIDList()])
    
    if step % 400 == 0:
        traci.trafficlight.setPhase("J0", 0) # N-S Green
    elif step % 400 == 200:
        traci.trafficlight.setPhase("J0", 2) # E-W Green
    step += 1

traci.close()
print(f"HONEST FIXED TOTAL: {total_waiting_time_fixed}")