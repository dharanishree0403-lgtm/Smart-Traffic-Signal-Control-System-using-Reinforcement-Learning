import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# --- 1. CONFIGURATION & DATA ---
# Actual values from your honest simulation runs
fixed_total_waiting = 169794.0
rl_total_waiting = 43974.0

# Calculate Efficiency % for the current simulation
efficiency_gain = ((fixed_total_waiting - rl_total_waiting) / fixed_total_waiting) * 100

# Load training history
try:
    df = pd.read_csv("training_log.csv")
    # Normalize rewards to a 0-100% Efficiency scale for the graph
    df['efficiency'] = (df['reward'] - df['reward'].min()) / (df['reward'].max() - df['reward'].min()) * 100
    df['smooth_eff'] = df['efficiency'].rolling(window=200).mean()
except Exception as e:
    print(f"Error reading training_log.csv: {e}")
    df = pd.DataFrame()

# --- 2. PLOTTING THE DASHBOARD ---
fig = plt.figure(figsize=(14, 10))
grid = plt.GridSpec(2, 2, hspace=0.4, wspace=0.3)

# GRAPH 1: TRAINING PROGRESS (Episodes vs Efficiency)
ax1 = fig.add_subplot(grid[0, :])
if not df.empty:
    ax1.plot(df['episode'], df['smooth_eff'], color='#1f77b4', linewidth=1.5, label='Learning Curve')
    ax1.fill_between(df['episode'], df['smooth_eff'], color='#1f77b4', alpha=0.1)
    ax1.set_title("TRAINING PHASE: EVOLUTION OF AGENT EFFICIENCY", fontsize=14, fontweight='bold')
    ax1.set_xlabel("Episode Number")
    ax1.set_ylabel("Efficiency (%)")
    ax1.grid(True, linestyle='--', alpha=0.5)
    ax1.set_ylim(0, 105)

# GRAPH 2: CURRENT SIMULATION COMPARISON (Bar Chart)
ax2 = fig.add_subplot(grid[1, 0])
labels = ['Fixed Timer', 'RL Agent']
values = [fixed_total_waiting, rl_total_waiting]
colors = ['#95a5a6', '#2ecc71']

bars = ax2.bar(labels, values, color=colors, width=0.5)
ax2.set_title("CURRENT SIMULATION: TOTAL DELAY", fontsize=12, fontweight='bold')
ax2.set_ylabel("Waiting Time (Units)")

# Add value labels on top of bars
for bar in bars:
    height = bar.get_height()
    ax2.text(bar.get_x() + bar.get_width()/2., height + 3000,
             f'{int(height)}', ha='center', va='bottom', fontweight='bold')

# GRAPH 3: PERFORMANCE METRIC (Pie Chart or Text Summary)
ax3 = fig.add_subplot(grid[1, 1])
ax3.axis('off')
metric_text = (
    f"SYSTEM VERDICT\n\n"
    f"Fixed System Delay: {int(fixed_total_waiting)}\n"
    f"RL System Delay: {int(rl_total_waiting)}\n"
    f"--------------------------\n"
    f"NET EFFICIENCY GAIN:\n"
    f"{efficiency_gain:.2f}%"
)
ax3.text(0.5, 0.5, metric_text, fontsize=15, ha='center', va='center', 
         fontweight='bold', color='#2c3e50', bbox=dict(facecolor='none', edgecolor='#2c3e50', pad=10))

plt.suptitle(f"TRAFFIC AI PROJECT: PERFORMANCE ANALYSIS", fontsize=18, fontweight='bold', y=0.95)
plt.savefig("Final_Project_Results.png", dpi=300)
print(f"Results processed successfully. Efficiency Gain: {efficiency_gain:.2f}%")
plt.show()